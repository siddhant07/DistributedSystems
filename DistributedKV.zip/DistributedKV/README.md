# Distributed Key Value Store

1. Open the config.py file and set the number of replicas you want
2. Run Server.py and select the type of server you want
3. Run the Client.py file and select the type of client you want to be
4. Run multiple Client.py instances to replicate multiple clients

# Make sure the server and clients are of same type
# You will get the output in the marked folders

